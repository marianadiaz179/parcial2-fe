import React from "react";
import { Link } from "react-router-dom";

function MainCard({name, img, isbn}) {
  return (
      <div>
      <img
        src={img}
        alt=""
        className="object-cover object-center rounded-md hover:scale-105 duration-200 w-full min-h-[300px] max-h-[300px]"
      />
      <div className="flex flex-col">
        <h1 className="text-blue-950 font-semibold capitalize">{name}</h1>
        <p className="text-neutral-400 text-sm">{isbn}</p>
      </div>
      </div>
  );
}

export default MainCard;
