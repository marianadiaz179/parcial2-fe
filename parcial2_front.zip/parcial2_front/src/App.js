import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { IntlProvider } from "react-intl";
import { Navbar, LoginModal } from "./components";
import * as Pages from "./pages";
import localeEs from "./locales/es.json";
import localeEn from "./locales/en.json";


function App() {

  const [modal, setModal] = useState(false);
  const [locale, setLocale] = useState(navigator.language);
  const [localeMsgs, setLocaleMsgs] = useState({});
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState("");
  const [roles, setRoles] = useState([""]);
  const [user, setUser] = useState([]);

  function decodeJWT(token) {
    if (token === "") return "";
    const base64Url = token.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      window
        .atob(base64)
        .split("")
        .map(function (c) {
          return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
    return JSON.parse(jsonPayload);
  }

  useEffect(() => {
    if (locale === "en") setLocaleMsgs(localeEn);
    else setLocaleMsgs(localeEs);
  }, [locale]);

  useEffect(() => {
    const decToken = decodeJWT(token);
    setRoles(decToken.roles);
    setUser(decToken.name);
  }, [token]);

  return (
    <>
      { (
        <IntlProvider locale={locale} messages={localeMsgs}>
          <Router>
            <LoginModal modal={modal} setModal={setModal} setToken={setToken} />
            <Routes>
              {/* Home - Landing */}
              <Route
                index
                element={
                  <Pages.Login/>
                }
              />

              <Route path="/home" element={<Pages.Home />} />
            </Routes>
          </Router>
        </IntlProvider>
      )}
    </>
  );

}

export default App;
