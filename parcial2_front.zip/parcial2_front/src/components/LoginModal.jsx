import React, { useState } from "react";
import login from "../assets/login.webp";
import { useNavigate } from "react-router-dom";
import { FormattedMessage } from "react-intl";
import axios from "../api";

export default function LoginModal({ modal, setModal, setToken }) {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [usernameErr, setUsernameErr] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordErr, setPasswordErr] = useState(false);
  const [response, setResponse] = useState({ status: "", msg: "" });

  const handleClose = () => {
    setUsername("");
    setUsernameErr(false);
    setPassword("");
    setPasswordErr(false);
    setResponse({ status: "", msg: "" });
    setModal(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setResponse({ status: "loading", msg: "" });

      if (username === "") {
        setUsernameErr(true);
        throw new Error("Ingresa un usuario");
      } else setUsernameErr(false);

      if (password === "") {
        setPasswordErr(true);
        throw new Error("Ingresa la contraseña");
      } else setPasswordErr(false);

      const body = { username, password };
      const resp = await axios.post("/users/login", body);
      setToken(resp.data.token);
      handleClose();
      navigate(`/?authOk=Has iniciado sesión como: ${username}`);
    } catch (error) {
      setResponse({ status: "error", msg: "Credenciales invalidas!" });
    }
  };

  return (
    (
      <div className="fixed top-30 left-30 flex justify-center items-center bg-neutral-700/70 w-full h-full z-50">
      <div class=" md:flex">
        <div
          class="relative overflow-hidden md:flex w-1/2 bg-green-600 i justify-around items-center hidden">
          <div>
            <img src={login} alt="login" className="justify-center items-center h-[125px]"></img>
            <p class="flex justify-center items-centertext-white mt-1">Encuentra hasta el libro que no estabas buscando</p>
            
          </div>
        </div>
        <div class="flex md:w-1/2 justify-center py-10 items-center bg-white">
          <form class="bg-white">
            <h1 class="text-gray-800 font-bold text-2xl mb-1">Tu Libreria Aliada</h1>
            
            <div class="flex items-center border-2 py-2 px-3 rounded-2xl mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" viewBox="0 0 20 20"
                fill="currentColor">
                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                  clip-rule="evenodd" />
              </svg>
              <input class="pl-2 outline-none border-none" type="text" name="" id="" placeholder="Full name" />
            </div>
            <div></div>
            <div class="flex items-center border-2 py-2 px-3 rounded-2xl">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" viewBox="0 0 20 20"
                fill="currentColor">
                <path fill-rule="evenodd"
                  d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                  clip-rule="evenodd" />
              </svg>
              <input class="pl-2 outline-none border-none" type="text" name="" id="" placeholder="Password" />
            </div>
            <button type="submit" class="block w-full bg-gray-600 mt-4 py-2 rounded-2xl text-white font-semibold mb-2">Login</button>
            <span class="text-sm ml-2 hover:text-blue-500 cursor-pointer">Forgot Password ?</span>
          </form>
        </div>
      </div>
      </div>

    )
  );
}
