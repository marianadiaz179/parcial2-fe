import React, { useEffect } from "react";
import { useNavigate, Outlet } from "react-router-dom";

export default function ProtectedUser({ roles }) {
  const navigate = useNavigate();

  useEffect(() => {
    if (!roles || !roles?.includes("user"))
      navigate("/?authErr=Debes iniciar sesión como usuario!");
  }, [navigate, roles]);

  return <Outlet />;
}
