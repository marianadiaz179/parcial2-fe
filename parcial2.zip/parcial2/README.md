Para la ejecución del proyecto se debe primero correr la aplicación del back con el comando "npm start". Posteriormente se debe 
utilizar el mismo comando para correr el front.

La aplicación fue desarrollada utilizando react y se crearon dos páginas para manejar los requerimientos solicitados, se utilizó
Bootstrap y CSS para la creación del login, junto con inputs que permitieran el ingreso de los datos pertinentes. No fue posible
conectar correctamente el back por lo que no se realiza la verificación de usuario pero al oprimir el botón de iniciar sesión, redirecciona al Home que es donde se muestran los libros (Sin embargo, no muestra los libros porque no se conectó correctamente al back a pesar de intentarlo directamente con fetch o con axios)

La página de login utilizó el useEffect para intentar cambiar el lenguaje y generar la internalización, pero a pesar de que si están los archivos locales y el botón que permite el cambio, estos cambios no se mantienen correctamente. Se utilizaton links y rutas para conectar las diferentes páginas creadas.

Mariana Díaz
202020993