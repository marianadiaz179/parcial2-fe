import { LoginModal } from "../components";

export default function Login() {
  return (
    <div>
        <LoginModal></LoginModal>
    </div>
  )
}
