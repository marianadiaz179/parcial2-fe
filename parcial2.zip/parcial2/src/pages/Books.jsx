import React from "react";
import { useState, useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FormattedMessage } from "react-intl";

export default function Books() {
  const [selectedBook, setSelectedBook] = useState(null);
  const [books, setBooks] = useState([]);

  const handleBookClick = (book) => {
    setSelectedBook(book);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:3000/books');
        if (response.ok) {
          const data = await response.json();
          setBooks(data);
        } else {
          throw new Error('Error al obtener los libros');
        }
      } catch (error) {
        // Manejo de errores
      }
    };

    fetchData();
  }, []);

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6">
          <h2><FormattedMessage id="LibrosDisponibles" /> </h2>
          <div className="card-columns">
            {books.map((book) => (
              <div key={book.id} className="card" onClick={() => handleBookClick(book)}>
                <img src={book.image} className="card-img-top" alt={book.name} />
                <div className="card-body">
                  <h5 className="card-title">{book.name}</h5>
                  <p className="card-text">ISBN: {book.isbn}</p>
                </div>
              </div>
            ))} 
          </div>
        </div>
        <div className="col-md-6">
          <h2><FormattedMessage id="LibroDetail" /></h2>
          {selectedBook ? (
            <table className="table">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>ISBN</th>
                  <th>Detalles</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{selectedBook.name}</td>
                  <td>{selectedBook.isbn}</td>
                  <td>{selectedBook.details}</td>
                </tr>
              </tbody>
            </table>
          ) : (
            <p>Selecciona un libro para ver los detalles</p>
          )}
        </div>
      </div>
    </div>
  );
};
