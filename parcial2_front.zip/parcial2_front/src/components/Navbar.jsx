import React, { useState } from "react";
import { NavLink, Link, useLocation, useNavigate } from "react-router-dom";
import { FormattedMessage } from "react-intl";
import es from "../assets/es.png";
import en from "../assets/en.png";
import { GiHamburgerMenu } from "react-icons/gi";

const links = [
  {
    name: <FormattedMessage id="NavHome" />,
    link: "/",
  },
  {
    name: <FormattedMessage id="NavCities" />,
    link: "/destinos",
  },
  {
    name: <FormattedMessage id="NavPackages" />,
    link: "/paquetes",
  },
];

function Navbar({ modal, setModal, locale, setLocale, user, setToken }) {
  const location = useLocation();
  const navigate = useNavigate();

  const [hamburger, setHamburger] = useState(false);

  return (
    <nav
      className={`flex justify-between items-center px-8 sm:px-12 mb-1 w-full h-20 ${
        location.pathname === "/" && "absolute z-10"
      }`}
    >

      {/* links */}
      <div className="hidden md:flex items-center gap-x-10 gap-y-7">
        {links.map((link) => (
          <NavLink
            key={link.link}
            to={link.link}
            className="text-neutral-500 hover:text-neutral-800 text-xl font-medium"
          >
            {link.name}
          </NavLink>
        ))}
      </div>

      <div className="hidden md:flex items-center gap-x-7 rounded-xl bg-white/30 px-5 py-2">
        {/* login */}
        {user ? (
          <button
            className="text-teal-800 hover:text-teal-900 hover:underline text-lg font-medium"
            onClick={() => {
              setToken("");
              navigate("/?authOk=Has cerrado sesión exitosamente!");
            }}
          >
            {user}
          </button>
        ) : (
          <button
            className="text-teal-800 hover:text-teal-900 hover:underline text-lg font-medium"
            onClick={() => setModal(true)}
          >
            <FormattedMessage id="NavSign" />
          </button>
        )}

        {/* lang */}
        {locale.includes("en") ? (
          <button
            className="w-[20px] aspect-square"
            onClick={() => setLocale("es-ES")}
          >
            <img src={en} alt="english" />
          </button>
        ) : (
          <button
            className="w-[20px] aspect-square"
            onClick={() => setLocale("en")}
          >
            <img src={es} alt="español" />
          </button>
        )}
      </div>

      {/* hamburger */}
      <div className="flex md:hidden">
        <button
          className="text-3xl"
          onClick={() => setHamburger((prev) => !prev)}
        >
          <GiHamburgerMenu />
        </button>
      </div>

      {hamburger && (
        <div className="absolute top-16 left-0 flex flex-col gap-y-3 bg-teal-700/90 p-5 w-full z-10">
          {/* links */}
          {links.map((link) => (
            <NavLink
              key={link.link}
              to={link.link}
              className="text-neutral-300 hover:text-neutral-800 text-lg font-medium"
              onClick={() => setHamburger(false)}
            >
              {link.name}
            </NavLink>
          ))}
          {locale.includes("en") ? (
            <button
              className="w-[20px] aspect-square"
              onClick={() => {
                setLocale("es-ES");
                setHamburger(false);
              }}
            >
              <img src={en} alt="english" />
            </button>
          ) : (
            <button
              className="w-[20px] aspect-square"
              onClick={() => {
                setLocale("en");
                setHamburger(false);
              }}
            >
              <img src={es} alt="español" />
            </button>
          )}
        </div>
      )}
    </nav>
  );
}

export default Navbar;
