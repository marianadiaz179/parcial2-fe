import React, { useEffect } from "react";
import { useNavigate, Outlet } from "react-router-dom";

export default function ProtectedAdmin({ roles }) {
  const navigate = useNavigate();

  useEffect(() => {
    if (!roles || !roles?.includes("admin"))
      navigate("/?authErr=Debes iniciar sesión como administrador!");
  }, [navigate, roles]);

  return <Outlet />;
}
