import React from "react";
import "./Login.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Libros from "../assets/libros.png";
import { FormattedMessage } from "react-intl";
import es from "../assets/es.png";
import en from "../assets/en.png";
import { Link } from "react-router-dom";


export default function Login({ locale, setLocale }) {

  return (
    <div class="fondo">
      <div class="container">
        <div class="row m-5 no-gutters shadow-lg">
          <div class="col-md-6 d-none d-md-block">
            <img alt="" src={Libros} />
            <p>
              <FormattedMessage id="LibrosDesc" />
            </p>
          </div>
          <div class="col-md-6 bg-white p-5">
            <h3 class="pb-3"><FormattedMessage id="Titulo" /></h3>
            <div class="form-style">
              <form>
                <div class="form-group pb-3">
                  <h2><FormattedMessage id="Username" /></h2>
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></input>
                </div>
                <div class="form-group pb-3">
                  <h2><FormattedMessage id="Password" /> </h2>
                  <input type="password" 
                  class="form-control"
                  ></input>
                </div>
                <div class="d-flex align-items-center justify-content-between">
                  <div class="d-flex align-items-center"><input name="" type="checkbox" value="" /> <span class="pl-2 font-weight-bold">Remember Me</span></div>
                  <div><a href="#"><FormattedMessage id="OlvidoPassword" /></a></div>
                </div>
                <div class="pb-2">
                  <Link to="books" className="Link">
                    <button type="submit" class="btn btn-dark w-100 font-weight-bold mt-2"><FormattedMessage id="login" /></button>
                  </Link>
                </div>
                <div class="pb-2">
                  {/* lang */}
                  {locale.includes("en") ? (
                    <button
                      class="btn btn-dark w-90 font-weight-bold mt-2"
                      onClick={() => setLocale("es-ES")}
                    >
                      <img class="imgboton" src={en} alt="english" />
                    </button>
                  ) : (
                    <button
                      class="btn btn-dark w-90 font-weight-bold mt-2"
                      onClick={() => setLocale("en")}
                    >
                      <img class="imgboton" src={es} alt="español" />
                    </button>
                  )}
                </div>
              </form>

            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
