import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { IntlProvider } from "react-intl";
import * as Pages from "./pages";
import * as Protected from "./components/Protected";
import axios from "./api";
import localeEs from "./locales/es.json";
import localeEn from "./locales/en.json";

function App() {
  const [locale, setLocale] = useState(navigator.language);
  const [localeMsgs, setLocaleMsgs] = useState({});
  const [books, setBooks] = useState([]);
  const [token] = useState("");
  const [roles, setRoles] = useState([""]);

  function decodeJWT(token) {
    if (token === "") return "";
    const base64Url = token.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      window
        .atob(base64)
        .split("")
        .map(function (c) {
          return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
    return JSON.parse(jsonPayload);
  }

  useEffect(() => {
    const fetchData = async () => {
      try {
        // destinos
        const booksFetch = await axios.get("books");
        setBooks(booksFetch.data);

      } catch (error) {
        // Manejo de errores
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (locale === "en") setLocaleMsgs(localeEn);
    else setLocaleMsgs(localeEs);
  }, [locale]);

  useEffect(() => {
    const decToken = decodeJWT(token);
    setRoles(decToken.roles);
  }, [token]);

  return (
    <> (
      <IntlProvider locale={locale} messages={localeMsgs}>
        <Router>
          <Routes>
            {/* Home - Landing */}
            <Route
              index
              element={<Pages.Login locale ={locale} setLocale={setLocale} />}
            />

            {/* HU - Crear ciudades - ruta protegida */}
                <Route
                  path="books"
                  element={<Pages.Books books = {books} token={token} />}
                />

            {/* HU - Crear ciudades - ruta protegida */}
            <Route element={<Protected.ProtectedAdmin roles={roles}/>}>
                <Route
                  path="books"
                  element={<Pages.Books token={token} />}
                />
              </Route>

          </Routes>
        </Router>
      </IntlProvider>
      )
    </>
  );
}

export default App;

