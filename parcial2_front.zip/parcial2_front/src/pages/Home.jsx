import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { FormattedMessage } from "react-intl";
import { MainCard} from "../components";
import axios from "../api";

export default function Home() {

  const [searchParams] = useSearchParams();
  const [libros, setLibros] = useState([]);

  const getLibros = async () => {
    try {
      const librosFetch = await axios.get(
        `libros`
      );
      setLibros(librosFetch.data);
    } catch (error) {
      alert("Error: El servidor no está corriendo");
    }
  };

  getLibros();

  return (

    
    <div className="flex flex-col gap-y-20 w-screen">
      {/* libros */}
      <section className="flex flex-col px-12 md:px-20 lg:px-40">
        {/* heading */}
        <div className="flex flex-col gap-y-2">
          <h1 className="capitalize text-4xl text-blue-950 font-semibold">
            Libros
          </h1>
          <p className="text-neutral-600 text-lg">
            Nuestros libros
          </p>
        </div>

        {/* libros */}
        <div className="flex flex-wrap gap-y-5">
          {libros.map((libro) => (
            <MainCard
              key={libro.id}
              name = {libro.name}
              img={libro.img}
              isbn = {libro.isbn}
          />
          ))}
        </div>
      </section>
    </div>
  );
}
